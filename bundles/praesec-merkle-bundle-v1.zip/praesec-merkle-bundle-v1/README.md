# Praesec Merkle Transparency Bundle v1

This bundle allows offline verification of:
- Signed Merkle root
- Inclusion proof for Epoch 3

## Verify
```bash
python verify_merkle_bundle.py

---

### 2️⃣ `verify_merkle_bundle.py`
**File name**