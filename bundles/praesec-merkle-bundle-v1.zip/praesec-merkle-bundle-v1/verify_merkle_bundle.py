import json
import hashlib
from cryptography.hazmat.primitives import serialization

ROOT_JSON = "merkle_root.json"
ROOT_SIG = "merkle_root.sig"
PUBKEY = "checkpoint_public.pem"
INCLUSION = "inclusion_epoch_3.json"

# ---------- Canonical JSON ----------

def canonical_json(obj) -> bytes:
    return json.dumps(
        obj,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False
    ).encode("utf-8")

# ---------- Crypto ----------

def load_pubkey():
    with open(PUBKEY, "rb") as f:
        return serialization.load_pem_public_key(f.read())

# ---------- Merkle Root Verification ----------

def verify_merkle_root():
    root_obj = json.load(open(ROOT_JSON))
    sig = bytes.fromhex(open(ROOT_SIG).read().strip())
    pub = load_pubkey()

    pub.verify(sig, canonical_json(root_obj))
    print("✅ Merkle root signature verified")

    return root_obj["root"], root_obj["size"]

# ---------- Inclusion Verification ----------

def verify_inclusion(root_hash: str, tree_size: int):
    proof = json.load(open(INCLUSION))

    leaf = proof.get("log_hash")
    if not leaf:
        raise Exception("❌ Inclusion proof missing log_hash")

    # ✅ SINGLE-LEAF TREE (your current case)
    if tree_size == 1:
        if leaf != root_hash:
            raise Exception("❌ Single-leaf inclusion failed")
        print("✅ Inclusion proof verified (single-leaf tree)")
        return

    # MULTI-LEAF TREE (future)
    h = bytes.fromhex(leaf)
    for step in proof["proof"]:
        sibling = bytes.fromhex(step["hash"])
        if step["position"] == "left":
            h = hashlib.sha256(sibling + h).digest()
        else:
            h = hashlib.sha256(h + sibling).digest()

    if h.hex() != root_hash:
        raise Exception("❌ Inclusion proof invalid")

    print("✅ Inclusion proof verified")

# ---------- Entry ----------

def main():
    root_hash, size = verify_merkle_root()
    verify_inclusion(root_hash, size)
    print("✅ MERKLE BUNDLE VERIFIED — cryptographically sound")

if __name__ == "__main__":
    main()